Doku:		../Aufgabe 2 Twist.pdf
App:		/App/Twist.exe
Beispiele:	/Beispiele/
Code:		/Twist/
		           TwistAPI	für Algorithmus
		           TwistGUI	für GUI
				   
In dem Beispiel-Ordner sind die Beispiele der BwInf Seite und 3 eigene Beispiele vorhanden, wobei jedes Beispiel in jeweils 5 Varianten vorhanden ist;
Original:							Der Originale Text									
Twisted:							Das Original nach twisten mit dem Programm
Detwisted:							Die getwistete Variante nach enttwisten mit dem Programm unter Nutzung des Standard-Wörterbuches das von der BwInf-Seite bereitgestellt wurde
Detwisted with Extended.langcook:	Die getwistete Variante nach enttwisten mit dem Programm unter Nutzung eines eigenen Wörterbuches erstellt aus german.7z von https://sourceforge.net/projects/germandict/files/
Detwisted with Custom.langcook:		Die getwistete Variante nach enttwisten mit dem Programm unter Nutzung eines eigenen Wörterbuches erstellt aus german.7z von https://sourceforge.net/projects/germandict/files/ zusammen mit dem von der BwInf bereitgestelltem Wörterbuches und allen Orginal-Versionen der Beispiele

Die Wörterbücher und die damit verbundenen .langcooks befinden sich unter /App/LangCooks/

Alle Beispiele sind in UTF8 gespeichert, und das Programm liest nur UTF8 Dateien ein.