Generiert aus german.7z von https://sourceforge.net/projects/germandict/files/
Dateien nicht hier enthalten aufgrund des 40MB Limit