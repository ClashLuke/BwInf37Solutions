Doku:		../Aufgabe 5 Widerstand.pdf
App:		/App/Widerstand.exe
Beispiele:	/Beispiele/
Code:		/Widerstand/
			            WiderstandAPI	für Algorithmus
			            WiderstandGUI	für GUI