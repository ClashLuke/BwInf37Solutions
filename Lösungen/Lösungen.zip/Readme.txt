Team-Name: Bruteforce
Team-ID: 00139
Mitglieder: Nikolas Kilian, Paul Cronin, Lucas Nestler, Johannes v. Stoephasius

An vielen Stellen des Projektes werden die selbst-geschriebenen Libraries MaterialDesign2, RandomHelper, Localization und SomeExtensions verwendet. 
Der Code dieser Bibliotheken befindet sich unter /Libraries/, und um die Projekte vom Source Code zu kompilieren müssen diese zuerst kompiliert (Release) werden.