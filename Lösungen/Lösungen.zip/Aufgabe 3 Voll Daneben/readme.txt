Doku:		../Aufgabe 3 VollDaneben.pdf
App:		/App/VollDaneben.exe
Beispiele:	/Beispiele/
Code:		/VollDaneben/
			            VollDanebenAPI	für Algorithmus
			            VollDanebenGUI	für GUI