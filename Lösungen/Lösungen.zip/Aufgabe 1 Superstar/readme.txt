Doku:		../Aufgabe 1 Superstar.pdf
App:		/App/Superstar.exe
Beispiele:	/Beispiele/
Code:		/Superstar/
			           SuperstarAPI	für Algorithmus
			           SuperstarGUI	für GUI