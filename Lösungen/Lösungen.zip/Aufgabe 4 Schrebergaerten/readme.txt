Doku:		../Aufgabe 4 Schrebergaerten.pdf
App:		/App/Schrebergaerten.exe
Beispiele:	/Beispiele/
Code:		/Schrebergaerten/
			                 SchrebergaertenAPI	und
			                 Evolution         	für Algorithmus
			                 SchrebergaertenGUI	für GUI