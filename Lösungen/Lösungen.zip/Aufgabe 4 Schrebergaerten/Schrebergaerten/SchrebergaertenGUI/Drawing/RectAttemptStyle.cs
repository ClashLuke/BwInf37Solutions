﻿using Color = System.Drawing.Color;

namespace SchrebergaertenGUI.Drawing
{
    public class RectAttemptStyle
    {
        public Color StrokeColor, FillColor;
        public int StrokeThickness;
    }
}
